package com.example.demo.Controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.User;
import com.example.demo.Service.UserService;

@RestController
@CrossOrigin(origins = "*")
public class RegistrationController {

    private UserService userService;

    public RegistrationController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/registeruser")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        
//    	 boolean isPasswordValid = userService.validatePassword(user.getMobileNumber(), user.getPassword());
//         if (!isPasswordValid) {
//             return new ResponseEntity<>("Invalid password", HttpStatus.BAD_REQUEST);
//         }
    	
    	
    	User registerdUser = userService.registerUser(user);
        return new ResponseEntity<>("Registration successful", HttpStatus.CREATED);
    }
}
