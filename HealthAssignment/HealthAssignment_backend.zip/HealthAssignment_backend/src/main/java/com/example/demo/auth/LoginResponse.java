package com.example.demo.auth;


public class LoginResponse {
    private String token;
    private String message;

    // Constructors, getters, and setters

    public LoginResponse() {
    }

    public LoginResponse(String token, String message) {
        this.token = token;
        this.message = message;
    }

    public LoginResponse(boolean success, String message2) {
		// TODO Auto-generated constructor stub
    	
	}

	public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
