package com.example.demo.Service;

import com.example.demo.Entity.User;

public interface UserService {
	
	public User registerUser(User user);

	boolean validatePassword(String mobileNumber,String password);
	
	
}
