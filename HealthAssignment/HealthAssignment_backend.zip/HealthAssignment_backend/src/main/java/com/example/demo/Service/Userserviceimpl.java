package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.User;
import com.example.demo.Repo.UserRepo;

@Service
public class Userserviceimpl implements UserService {
	
	private UserRepo userRepo;
	private BCryptPasswordEncoder passwordEncoder;
	
	   @Autowired
	    public Userserviceimpl(UserRepo userRepo, BCryptPasswordEncoder passwordEncoder) {
	        this.userRepo = userRepo;
	        this.passwordEncoder = passwordEncoder;
	    }
	
	public Userserviceimpl() {
		// TODO Auto-generated constructor stub
	}

	public User registerUser(User user) {
		
		 String encodedPassword = passwordEncoder.encode(user.getPassword());
	        
		User u = new User();
		u.setPassword(encodedPassword);
		u.setFirstName(user.getFirstName());
		u.setLastName(user.getLastName());
		u.setDateOfBirth(user.getDateOfBirth());
		u.setAge(user.getAge());
		u.setMobileNumber(user.getMobileNumber());
		
		userRepo.save(u);
		
		return u;
	}

	@Override
	public boolean validatePassword(String mobileNumber, String password) {
        User user = userRepo.findByMobileNumber(mobileNumber);
        if (user == null) {
            return false; // User not found
        }

        // Compare the password with the stored password
        return passwordEncoder.matches(password, user.getPassword());
    }
}
