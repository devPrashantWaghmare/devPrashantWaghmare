package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.User;
import com.example.demo.Repo.UserRepo;
import com.example.demo.auth.LoginRequest;
import com.example.demo.auth.LoginResponse;

@Service
public class LoginService {

    private final UserRepo userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    @Autowired
    public LoginService(UserRepo userRepository, BCryptPasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public LoginResponse login(LoginRequest loginRequest) {
        User user = userRepository.findByMobileNumber(loginRequest.getMobileNumber());
        boolean success = user != null && passwordEncoder.matches(loginRequest.getPassword(), user.getPassword());
        String message = success ? "Login successful" : "Invalid mobile number or password";
        return new LoginResponse(success, message);
    }
}
