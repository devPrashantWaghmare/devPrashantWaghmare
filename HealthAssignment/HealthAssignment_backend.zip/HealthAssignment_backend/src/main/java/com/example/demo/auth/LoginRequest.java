package com.example.demo.auth;


public class LoginRequest {
    private String mobileNumber;
    private String password;

    // Constructors, getters, and setters

    public LoginRequest() {
    }

    public LoginRequest(String username, String password) {
        this.mobileNumber = username;
        this.password = password;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setUsername(String username) {
        this.mobileNumber = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
