import React, { useState } from 'react';
import './assets/ForgotPassword.css';

function ForgotPasswordPage() {
  const [email, setEmail] = useState('');

  const handleResetPassword = (event) => {
    event.preventDefault();
    // Here you can implement the logic for resetting the password using the provided email
    console.log('Reset Password:', email);
  };

  return (
    <div>
      <h2>Forgot Password</h2>
      <form onSubmit={handleResetPassword}>
        <div>
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <button type="submit">Reset Password</button>
      </form>
    </div>
  );
}

export default ForgotPasswordPage;
