import React, { useState } from 'react';
import { Link, Outlet } from 'react-router-dom';

function Dashboard() {
  const [selectedOption, setSelectedOption] = useState(null);

  const handleOptionSelect = (option) => {
    setSelectedOption(option);
  };

  return (
    <div className="dashboard-container">
      <div className="sidebar">
        <h2>Dashboard</h2>
        <nav>
          <ul>
            <li>
              <Link to="/dashboard/art-therapy" onClick={() => handleOptionSelect('art-therapy')}>
                Art Therapy and Creative Expression
              </Link>
            </li>
            <li>
              <Link to="/dashboard/intergenerational-connection" onClick={() => handleOptionSelect('intergenerational-connection')}>
                Intergenerational Connection
              </Link>
            </li>
          </ul>
        </nav>
      </div>
      <div className="main-content">
        {selectedOption && (
          <div>
            <h3>{selectedOption}</h3>
            {/* Render the appropriate content based on the selected option */}
            {selectedOption === 'art-therapy' && (
              <div className="description-section">
                <h3>Art Therapy</h3>
                <p>
                  Art therapy is a form of expressive therapy that uses the creative process of making art to improve a person's physical, mental, and emotional well-being. It provides a means of self-expression and can be particularly beneficial for individuals dealing with stress, trauma, or psychological challenges.
                </p>
              </div>
            )}
            {selectedOption === 'intergenerational-connection' && (
              <div className="description-section">
                <h3>Intergenerational Connection</h3>
                <p>
                  Intergenerational connection refers to the meaningful interactions and relationships between different generations, such as children, adults, and seniors. It promotes mutual understanding, knowledge sharing, and emotional support across age groups. Building intergenerational connections can lead to positive outcomes for individuals of all ages, fostering a sense of belonging, purpose, and social cohesion.
                </p>
              </div>
            )}
          </div>
        )}
        <Outlet />
      </div>
      <div className="sidebar">
        {/* Add the statistics section here */}
        <div className="note-section">
          <h3>Psychological Problems Faced by Elders</h3>
          <ul>
            <li>Depression</li>
            <li>Anxiety</li>
            <li>Loneliness</li>
            {/* Add more psychological problems */}
          </ul>
        </div>
       
      </div>
    </div>
  );
}

export default Dashboard;
