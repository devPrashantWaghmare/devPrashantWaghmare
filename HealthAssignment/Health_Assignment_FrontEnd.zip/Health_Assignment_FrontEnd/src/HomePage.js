import React from 'react';
import './assets/HomePage.css';
import { Link } from 'react-router-dom';

function HomePage() {
  return (
    <div className="homepage-container">
      <div className="centered-content">
        <div className="hero-section">
          <h1>Welcome to the Health App!</h1>
          <p>Your all-in-one platform for managing your health and wellness.</p>
          <Link to="/login">Get Started</Link>
        </div>
        <div className="features-section">
          <h2>Log in now to experience the Magic touch</h2>
          <div className="feature-card">
            <img src="feature-1-icon.png" alt="Feature 1" />
            <h3>Personal Health Tracking</h3>
            <p>Track and monitor your health metrics, such as steps, heart rate, sleep, and more.</p>
          </div>
          <div className="feature-card">
            <img src="feature-2-icon.png" alt="Feature 2" />
            <h3>Nutrition Planning</h3>
            <p>Create personalized meal plans and track your daily nutritional intake.</p>
          </div>
          <div className="feature-card">
            <img src="feature-3-icon.png" alt="Feature 3" />
            <h3>Exercise Workouts</h3>
            <p>Access a library of workout routines and exercise videos tailored to your fitness goals.</p>
          </div>
        </div>
        <div className="testimonial-section">
          <h2>What Our Users Say</h2>
          <div className="testimonial-card">
            <img src="user-avatar.png" alt="User Avatar" />
            <p>"The Health App has helped me stay on top of my health goals and make positive changes in my lifestyle."</p>
            <span>- John Doe</span>
          </div>
        </div>
        <div className="cta-section">
          <h2>Start Your Health Journey Today</h2>
          <p>Log in now to experience the Magic touch</p>
          <button className="cta-button">Sign Up</button>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
