import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// Create a root instance using ReactDOM.createRoot
const root = ReactDOM.createRoot(document.getElementById('root'));

// Render the root component (App) to the DOM
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
