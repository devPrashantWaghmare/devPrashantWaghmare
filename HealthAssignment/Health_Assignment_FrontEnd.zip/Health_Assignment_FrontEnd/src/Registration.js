import React, { useState } from 'react';
import axios from 'axios';
import './assets/Registration.css';
import { useNavigate } from 'react-router-dom';

function Registration() {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [age, setAge] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [registrationStatus, setRegistrationStatus] = useState('');

  const navigate = useNavigate();  

  const handleFormSubmit = (event) => {
    event.preventDefault();

    if (password !== confirmPassword) {
        console.error('Password and Confirm Password do not match');
        return;
      }

    const userData = {
      firstName: firstName,
      lastName: lastName,
      dateOfBirth: dateOfBirth,
      age: age,
      mobileNumber: mobileNumber,
      password: password,
    };

    const api = axios.create({
      baseURL: 'http://localhost:8080', // Replace with your backend server URL
    });

    api.post('/registeruser', userData)
      .then((response) => {
        console.log('Registration successful:', response.data);
        setRegistrationStatus('Registration successful');
        navigate('/login'); // Navigate to the login page
      })
      .catch((error) => {
        console.error('Registration failed:', error);
      });
  };

  return (
    <div className="registration-form">
      <h1>Registration Page</h1>
      <form onSubmit={handleFormSubmit}>
        <div>
          <label htmlFor="firstName">First Name:</label>
          <input
            type="text"
            id="firstName"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="lastName">Last Name:</label>
          <input
            type="text"
            id="lastName"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="dateOfBirth">Date of Birth:</label>
          <input
            type="date"
            id="dateOfBirth"
            value={dateOfBirth}
            onChange={(e) => setDateOfBirth(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="age">Age:</label>
          <input
            type="number"
            id="age"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="mobileNumber">Mobile Number:</label>
          <input
            type="tel"
            id="mobileNumber"
            value={mobileNumber}
            onChange={(e) => setMobileNumber(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="confirmPassword">Confirm Password:</label>
          <input
            type="password"
            id="confirmPassword"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
        </div>

        <button type="submit">Submit</button>
      </form>
      {registrationStatus && <p>{registrationStatus}</p>}
    </div>
  );
}

export default Registration;
