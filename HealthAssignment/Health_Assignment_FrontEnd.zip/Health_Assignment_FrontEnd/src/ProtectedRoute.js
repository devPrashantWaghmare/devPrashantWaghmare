import React from 'react';
import { Route, Navigate, useLocation } from 'react-router-dom';

const ProtectedRoute = ({ element: Element, ...rest }) => {
  // Replace isLoggedIn with your actual authentication logic
  const isLoggedIn = false;
  const location = useLocation();

  return isLoggedIn ? (
    <Route {...rest} element={<Element />} />
  ) : (
    <Navigate to="/login" state={{ from: location }} replace />
  );
};

export default ProtectedRoute;
