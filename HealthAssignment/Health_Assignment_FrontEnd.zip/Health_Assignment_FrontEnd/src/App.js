import React, { useState } from 'react';
import { BrowserRouter as Router, Link, Route, Routes } from 'react-router-dom';
import HomePage from './HomePage';
import Registration from './Registration';

import Login from './Login';
import ForgotPasswordPage from './ForgotPasswordPage';
import Dashboard from './Dashboard';
import ArtApp from './ArtApp';
import IntergenerationalApp from './IntergenerationalApp';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    // Perform your login logic here
    // Set the isLoggedIn state to true upon successful login
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    // Perform your logout logic here
    // Set the isLoggedIn state to false upon successful logout
    setIsLoggedIn(false);
  };

  return (
    <Router>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/register">Register</Link>
          </li>
          <li>
            {isLoggedIn ? (
              <button onClick={handleLogout}>Logout</button>
            ) : (
              <Link to="/login">Login</Link>
            )}
          </li>
        </ul>
      </nav>

      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/register" element={<Registration />} />
        <Route
          path="/login"
          element={<Login onLogin={handleLogin} isLoggedIn={isLoggedIn} />}
        />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/dashboard/art-therapy" element={<ArtApp />} />
          <Route path="/dashboard/intergenerational-connection" element={<IntergenerationalApp />} />



        
      </Routes>

    
    </Router>
  );
}

export default App;
