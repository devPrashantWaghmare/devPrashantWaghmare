import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './assets/Login.css'; // Import the CSS file
import axios from 'axios';


function LoginPage() {
  const [username, setUsername] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const navigate = useNavigate();

  const handleLogin = (event) => {
    event.preventDefault();
    // Here you can perform the login logic using the mobile number and password.
    console.log('Logged in:', {
      mobileNumber,
      password
    });

    const credentials = {
        username: username,
        password: password,
      };
  
      const api = axios.create({
        baseURL: 'http://localhost:8080', // Replace with your backend server URL
      });
  
      api
        .post('/login', credentials)
        .then((response) => {
          // Handle successful login
          // Store the user's authentication state (e.g., token or session information)
          // Redirect to the user's dashboard or home page
          navigate('/dashboard');
        })
        .catch((error) => {
          // Handle login error
          // Display an error message to the user
          setLoginError('Invalid username or password');
        });

  };

  const handleRegister = () => {
    console.log('Registration button clicked');
    // Implement your registration logic here
    // Redirect to the registration page
    navigate('/register');
  };

  const handleForgotPassword = () => {
    console.log('Forgot password button clicked');
    // Implement your forgot password logic here
    // Redirect to the forgot password page
    navigate('/forgot-password');
  };

  return (
    <div className="login-page">
      <div className="login-form">
        <h2>Please Ensure SpringBoot backend server is running before Login</h2>
        <h2>Login Page</h2>
        <form onSubmit={handleLogin}>
          <input
            type="tel"
            placeholder="Mobile Number"
            value={mobileNumber}
            onChange={(e) => setMobileNumber(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit">Login</button>
        </form>
        <div className="additional-options">
          <button onClick={handleRegister}>Register</button>
          <button onClick={handleForgotPassword}>Forgot Password</button>
        </div>
        {loginError && <p>{loginError}</p>}
      </div>
    </div>
  );
}

export default LoginPage;
