import React, { useState, useEffect, useRef } from 'react';
import './assets/Intergenerational.css';


function IntergenerationalApp() {
  const [isCalling, setIsCalling] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const [selectedPartner, setSelectedPartner] = useState(null);
  const [profile, setProfile] = useState({
    name: '',
    age: '',
    interests: '',
  });

  useEffect(() => {
    // Initialize video streams and set up video call
    const initializeVideo = async () => {
      try {
        // Access user media
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });

        // Attach local video stream
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }

        // Set up video call
        // ...

        setIsConnected(true);
      } catch (error) {
        console.log('Error accessing media devices:', error);
      }
    };

    if (isCalling) {
      initializeVideo();
    }

    // Clean up video streams and call on component unmount
    return () => {
      if (isConnected) {
        // Clean up video call
        // ...
      }
    };
  }, [isCalling]);

  const handleCall = () => {
    setIsCalling(true);
  };

  const handleHangup = () => {
    setIsCalling(false);
    setIsConnected(false);
    // Perform cleanup and hang up the video call
    // ...
  };

  const handleProfileChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handlePartnerSelect = (partner) => {
    setSelectedPartner(partner);
  };

  return (
    <div className="intergenerational-app-container">
      <table className="intergenerational-app-table">
        <tbody>
          <tr>
            <td>
              <div>
                <h4>Intergenerational Connection</h4>
                <h2>Please Click on : Start video Call </h2>
                <div>
                  {isCalling && !isConnected && <p>Connecting...</p>}
                  {!isCalling && !isConnected && (
                    <table>
                      <tr>

                            <div>
                            <h5>Create Your Profile</h5>
                            </div>
                          </tr>
                           <tr>
                           <label>
                              Name:
                              <input type="text" name="name" value={profile.name} onChange={handleProfileChange} />
                            </label>
                           </tr>
                        <tr>
                        <label>
                              Age:
                              <input type="number" name="age" value={profile.age} onChange={handleProfileChange} />
                            </label>
                        </tr>
                        <tr>
                        <label>
                              Interests:
                              <input type="text" name="interests" value={profile.interests} onChange={handleProfileChange} />
                            </label>
                        </tr>
                        <tr>
                          <br></br>
                        <img src="/path/to/person-image.jpg" alt="Person" />
                        <br></br>
                        <br></br>
                            <button  onClick={handleCall}>Start Video Call</button>
                            <br></br>
                            <br></br>
                            <h4>Please grant access to the camera and microphone to start the video call.</h4>
                       </tr>
                                       
                    </table>
                  )}
                </div>
                <div>
                  <h5>Choose a Video Call Partner</h5>
                  <ul>
                    <li onClick={() => handlePartnerSelect('Partner 1')}>Partner 1</li>
                    <li onClick={() => handlePartnerSelect('Partner 2')}>Partner 2</li>
                    <li onClick={() => handlePartnerSelect('Partner 3')}>Partner 3</li>
                  </ul>
                </div>
                <div>
                  <br></br>
            
                  <h5>Your Profile</h5>
                  <p>Name: {profile.name}</p>
                  <p>Age: {profile.age}</p>
                  <p>Interests: {profile.interests}</p>
                </div>
              </div>
            </td>
            <td>
              <div>
                
                <p>Benefits of intergenerational connection in addressing these issues.</p>
                <ul>
                  <li>Reduced feelings of loneliness and isolation</li>
                  <li>Improved mental and emotional well-being</li>
                  <li>Enhanced cognitive abilities</li>
                  
                  <li>Increased social interaction and sense of belonging</li>
                </ul>
                <p>By fostering intergenerational connections through video calls, we aim to improve the overall quality of life for elderlies and create a sense of purpose and companionship.</p>
              </div>
            </td>
          </tr>
          <tr>
              <div>
                <video ref={localVideoRef} autoPlay muted />
                <video ref={remoteVideoRef} autoPlay />
                
                <button onClick={handleHangup}>Hang Up</button>
            </div>
          
          </tr>
        </tbody>
      </table>
      
    </div>
  );
}

export default IntergenerationalApp;
