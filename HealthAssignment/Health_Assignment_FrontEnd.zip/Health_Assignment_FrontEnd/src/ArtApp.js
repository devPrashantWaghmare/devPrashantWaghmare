import React, { useState, useRef } from 'react';

function ArtApp() {
  const canvasRef = useRef(null);
  const [canvasColor, setCanvasColor] = useState('yellow');
  const [artwork, setArtwork] = useState('');

  const handleColorChange = (color) => {
    setCanvasColor(color);
  };

  const handleSaveArtwork = () => {
    const canvas = canvasRef.current;
    const image = canvas.toDataURL(); // Generate an image file from the canvas
    setArtwork(image);
  };

  const handleClearCanvas = () => {
    setCanvasColor('white');
    setArtwork('');
  };

  const handleShareArtwork = () => {
    // Logic to share or publish the artwork
    // ...
  };

  return (
    <div className="art-app-container">
      <table className="art-app-table">
        <tbody>
          <tr>
            <td>
              <h2>Art Therapy and Creative Expression</h2>
              <div>
                <h4>Canvas</h4>
                <canvas ref={canvasRef} style={{ background: canvasColor, width: '400px', height: '300px' }}></canvas>
                <br></br>
                <button onClick={handleClearCanvas}>Clear</button>
                <button onClick={() => handleColorChange('red')}>Red</button>
                <button onClick={() => handleColorChange('blue')}>Blue</button>
                <button onClick={() => handleColorChange('yellow')}>Yellow</button>
              </div>
              <div>
                <h4>Artwork</h4>
                {artwork && <img src={artwork} alt="Artwork" />}
                <button onClick={handleSaveArtwork}>Save Artwork</button>
                <button onClick={handleShareArtwork}>Share & Discuss your Artwork with buddies...</button>
              </div>
              <div>
                <h4>Tools</h4>
                <div className="tool-icons">
                  <img src="healthapp\src\assets\pencil-37254_1280.webp" alt="Pencil" />
                  <img src="brush-icon.png" alt="Brush" />
                  <img src="eraser-icon.png" alt="Eraser" />
                  {/* Add more tool icons */}
                </div>
              </div>
            </td>
            <td>
              <div className="text-section">
                <h3>Why Art Therapy?</h3>
                <p>
                  Art therapy offers a creative outlet for self-expression and can be particularly beneficial for seniors who face challenges in verbal communication or expressing emotions. It promotes mental well-being, reduces stress and anxiety, and enhances cognitive abilities.
                </p>
                <h3>Implementation</h3>
                <p>
                  Our art therapy implementation includes a canvas for creating digital artwork using various tools and colors. Users can freely express themselves, explore artistic techniques, and save their creations. Additionally, they have the option to share or publish their artwork, fostering a sense of community and connection.
                </p>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default ArtApp;
