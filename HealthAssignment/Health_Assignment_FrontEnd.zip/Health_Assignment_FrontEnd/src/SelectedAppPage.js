import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function Dashboard() {
  const [selectedApp, setSelectedApp] = useState('');

  const handleAppSelection = (app) => {
    setSelectedApp(app);
  };

  return (
    <div>
      <h1>Dashboard</h1>
      <p>Please select an app:</p>
      <ul>
        <li>
          <button onClick={() => handleAppSelection('Art Therapy and Creative Expression')}>
            Art Therapy and Creative Expression
          </button>
        </li>
        <li>
          <button onClick={() => handleAppSelection('Intergenerational Connection')}>
            Intergenerational Connection
          </button>
        </li>
      </ul>
      {selectedApp && (
        <div>
          <h2>{selectedApp}</h2>
          {selectedApp === 'Art Therapy and Creative Expression' && (
            <div>
              <h3>Art Therapy and Creative Expression App</h3>
              <p>This is the Art Therapy and Creative Expression app.</p>
              {/* Add more UI and features specific to the Art Therapy and Creative Expression app */}
            </div>
          )}
          {selectedApp === 'Intergenerational Connection' && (
            <div>
              <h3>Intergenerational Connection App</h3>
              <p>This is the Intergenerational Connection app.</p>
              {/* Add more UI and features specific to the Intergenerational Connection app */}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default Dashboard;
